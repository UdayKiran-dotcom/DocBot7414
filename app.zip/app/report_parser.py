# app/report_parser.py

import google.generativeai as genai
import os
import re # For regular expressions to parse input
from dotenv import load_dotenv
import streamlit as st
import pandas as pd # Import pandas for DataFrame
import logging # Add this line

# Configure logging (consider moving this to main.py or a config file for app-wide configuration)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Load API key from .env file
load_dotenv()

# Configure Gemini with API key
_api_key = os.getenv("GEMINI_API_KEY")
if not _api_key:
    logging.critical("CRITICAL ERROR: GEMINI_API_KEY not found in report_parser.py. Please set it in your .env file.")
    st.error("Configuration Error: API key not found for report parsing.")
    genai.configure(api_key="dummy_key") # Dummy key to prevent immediate crash
else:
    genai.configure(api_key=_api_key)
    logging.info("Gemini configured for report_parser.")


MODEL_NAME_FLASH = "gemini-2.0-flash"

# Initialize the generative model once globally for report explanation
report_explanation_model = None
try:
    report_explanation_model = genai.GenerativeModel(MODEL_NAME_FLASH)
    logging.info("Gemini model for report explanation initialized successfully.")
except Exception as e:
    logging.exception(f"Error initializing Gemini model for report explanation: {e}")
    st.error(f"Error initializing AI model for report explanation. Please check your API key and internet connection: {e}")


# --- Expanded Medical Report Normal Ranges Knowledge Base ---
# This dictionary holds normal ranges for common lab tests.
# This is a significantly expanded set covering CBC, CMP, Lipids, Thyroid, and more.
# Units are crucial. Ranges are general and can vary slightly by lab/region.
NORMAL_RANGES = {
    # Complete Blood Count (CBC)
    "wbc (white blood cell)": {"unit": "cells/mcL", "low": 4500, "high": 11000},
    "rbc (red blood cell)": {"unit": "cells/mcL", "low": 4.5, "high": 5.9, "gender_specific": {"male": {"low": 4.7, "high": 6.1}, "female": {"low": 4.2, "high": 5.4}}},
    "hemoglobin": {"unit": "g/dL", "low": 12.0, "high": 17.5, "gender_specific": {"male": {"low": 13.5, "high": 17.5}, "female": {"low": 12.0, "high": 15.5}}},
    "hematocrit": {"unit": "%", "low": 36.0, "high": 52.0, "gender_specific": {"male": {"low": 39.0, "high": 50.0}, "female": {"low": 35.0, "high": 45.0}}},
    "platelets": {"unit": "/uL", "low": 150000, "high": 450000},
    "mcv (mean corpuscular volume)": {"unit": "fL", "low": 80, "high": 100},
    "mch (mean corpuscular hemoglobin)": {"unit": "pg", "low": 27, "high": 33},
    "mchc (mean corpuscular hemoglobin concentration)": {"unit": "g/dL", "low": 32, "high": 36},
    "rdw (red cell distribution width)": {"unit": "%", "low": 11.5, "high": 14.5},
    "neutrophils": {"unit": "%", "low": 40, "high": 75},
    "lymphocytes": {"unit": "%", "low": 20, "high": 45},
    "monocytes": {"unit": "%", "low": 2, "high": 10},
    "eosinophils": {"unit": "%", "low": 0, "high": 6},
    "basophils": {"unit": "%", "low": 0, "high": 2},

    # Comprehensive Metabolic Panel (CMP)
    "glucose": {"unit": "mg/dL", "low": 70, "high": 99}, # Fasting glucose
    "bun (blood urea nitrogen)": {"unit": "mg/dL", "low": 7, "high": 20},
    "creatinine": {"unit": "mg/dL", "low": 0.6, "high": 1.2, "gender_specific": {"male": {"low": 0.7, "high": 1.3}, "female": {"low": 0.6, "high": 1.1}}},
    "sodium": {"unit": "mEq/L", "low": 135, "high": 145},
    "potassium": {"unit": "mEq/L", "low": 3.5, "high": 5.0},
    "chloride": {"unit": "mEq/L", "low": 96, "high": 106},
    "co2 (carbon dioxide)": {"unit": "mEq/L", "low": 23, "high": 29},
    "calcium": {"unit": "mg/dL", "low": 8.5, "high": 10.2},
    "protein (total)": {"unit": "g/dL", "low": 6.0, "high": 8.3},
    "albumin": {"unit": "g/dL", "low": 3.4, "high": 5.4},
    "bilirubin (total)": {"unit": "mg/dL", "low": 0.2, "high": 1.2},
    "alp (alkaline phosphatase)": {"unit": "U/L", "low": 44, "high": 147},
    "alt (alanine aminotransferase)": {"unit": "U/L", "low": 7, "high": 56},
    "ast (aspartate aminotransferase)": {"unit": "U/L", "low": 10, "high": 40},

    # Lipid Panel
    "cholesterol (total)": {"unit": "mg/dL", "low": 125, "high": 200}, # Desirable
    "ldl (low-density lipoprotein)": {"unit": "mg/dL", "high": 100}, # Optimal <100
    "hdl (high-density lipoprotein)": {"unit": "mg/dL", "low": 40}, # Good >60, Bad <40
    "triglycerides": {"unit": "mg/dL", "high": 150}, # Desirable <150

    # Thyroid Panel
    "tsh (thyroid stimulating hormone)": {"unit": "mIU/L", "low": 0.4, "high": 4.0},
    "free t4": {"unit": "ng/dL", "low": 0.8, "high": 1.8},
    "free t3": {"unit": "pg/mL", "low": 2.3, "high": 4.2},

    # Diabetes markers
    "hba1c": {"unit": "%", "high": 5.6}, # Normal <5.7%

    # Electrolytes (beyond CMP)
    "magnesium": {"unit": "mg/dL", "low": 1.7, "high": 2.2},
    "phosphate": {"unit": "mg/dL", "low": 2.5, "high": 4.5},

    # Other common tests
    "uric acid": {"unit": "mg/dL", "low": 3.5, "high": 7.2, "gender_specific": {"male": {"low": 3.5, "high": 7.2}, "female": {"low": 2.6, "high": 6.0}}},
    "vitamin d (25-hydroxy)": {"unit": "ng/mL", "low": 30, "high": 100}, # Optimal 30-80
    "iron": {"unit": "mcg/dL", "low": 60, "high": 170},
    "ferritin": {"unit": "ng/mL", "low": 20, "high": 250, "gender_specific": {"male": {"low": 20, "high": 500}, "female": {"low": 20, "high": 200}}},
}


def parse_lab_results(report_text):
    """
    Parses lab report text to extract test names, values, and units using regular expressions.
    This function is designed to be flexible with common lab report formats.
    """
    parsed_data = {}
    # Regex to capture test name (alphanumeric, spaces, hyphens, parentheses),
    # value (decimal numbers), and optional units.
    # It tries to match "Test Name: Value Unit" or "Test Name Value Unit" or "Test Name Value"
    # Added common delimiters like ':' and ' '
    # Also added common units that might be separated or attached.
    # Pattern: (Test Name Group)(Value Group)(Optional Unit Group)
    # Allows for multi-word test names and various unit formats.
    # Units can be: letters (e.g., g/dL, mg/dL, U/L, %), or /uL, cells/mcL, etc.
    lab_pattern = re.compile(
        r"([A-Za-z0-9\s\-\.\(\)]+?)\s*[:]?\s*(\d+\.?\d*)(?:\s*([a-zA-Z/%]+(?:/[a-zA-Z]+)?))?"
    )

    matches = lab_pattern.finditer(report_text)

    for match in matches:
        test_name_raw = match.group(1).strip()
        value_str = match.group(2)
        unit = match.group(3)

        # Normalize test name for lookup in NORMAL_RANGES
        test_name_normalized = test_name_raw.lower()
        # Simple normalization: remove common non-alphanumeric chars or extra spaces
        test_name_normalized = re.sub(r'[\(\)]', '', test_name_normalized).strip()
        test_name_normalized = re.sub(r'\s+', ' ', test_name_normalized) # Replace multiple spaces with single
        # Try to find a match in the keys of NORMAL_RANGES, allowing for partial matches or different phrasing
        found_key = None
        for key in NORMAL_RANGES.keys():
            # Check if the normalized test name is very similar or contained in a known key
            if test_name_normalized in key or key.startswith(test_name_normalized) or \
               test_name_normalized.startswith(key.split(' ')[0]): # e.g. "WBC" matches "wbc (white blood cell)"
                found_key = key
                break
        
        if found_key and value_str:
            try:
                parsed_data[found_key] = {
                    "value": float(value_str),
                    "unit": unit if unit else NORMAL_RANGES[found_key].get("unit", None) # Use parsed unit or default
                }
            except ValueError:
                logging.warning(f"Could not convert value '{value_str}' for test '{found_key}' to float.")
                continue # Skip if value is not a valid number
    
    if not parsed_data:
        logging.info("No lab results found in the provided text by the parser.")
    else:
        logging.info(f"Successfully parsed {len(parsed_data)} lab results.")
    return parsed_data

def analyze_report_data(parsed_data, gender="unknown"):
    """
    Analyzes parsed lab data against NORMAL_RANGES and identifies anomalies.
    Returns a list of dictionaries for DataFrame and a list of anomaly strings for AI explanation.
    """
    table_data_list = []
    anomalies = []

    for test_key, data in parsed_data.items():
        value = data["value"]
        unit = data["unit"]
        
        # Get the friendly name for display
        display_test_name = test_key.split('(')[0].strip().replace('_', ' ').title()

        if test_key in NORMAL_RANGES:
            reference_range_info = NORMAL_RANGES[test_key]
            
            # Determine the correct range based on gender if available
            current_low = reference_range_info.get("low")
            current_high = reference_range_info.get("high")
            range_unit = reference_range_info.get("unit")
            range_note = ""

            if "gender_specific" in reference_range_info:
                gender_ranges = reference_range_info["gender_specific"]
                if gender.lower() == "male" and "male" in gender_ranges:
                    current_low = gender_ranges["male"]["low"]
                    current_high = gender_ranges["male"]["high"]
                    range_note = " (Male)"
                elif gender.lower() == "female" and "female" in gender_ranges:
                    current_low = gender_ranges["female"]["low"]
                    current_high = gender_ranges["female"]["high"]
                    range_note = " (Female)"
                # If gender is not specified or doesn't match, use general range

            status = "Normal"
            anomaly_desc = ""

            # Only compare if we have valid low/high bounds
            if current_low is not None and current_high is not None:
                if value < current_low:
                    status = "Low"
                    anomaly_desc = f"{display_test_name}: {value} {unit} (Low - Normal range: {current_low}-{current_high} {range_unit}{range_note})"
                    anomalies.append(anomaly_desc)
                elif value > current_high:
                    status = "High"
                    anomaly_desc = f"{display_test_name}: {value} {unit} (High - Normal range: {current_low}-{current_high} {range_unit}{range_note})"
                    anomalies.append(anomaly_desc)
                else:
                    status = "Normal"
            elif current_high is not None and value > current_high: # For tests with only an upper limit (e.g., LDL, Triglycerides)
                status = "High"
                anomaly_desc = f"{display_test_name}: {value} {unit} (High - Normal: <{current_high} {range_unit}{range_note})"
                anomalies.append(anomaly_desc)
            elif current_low is not None and value < current_low: # For tests with only a lower limit (e.g., HDL)
                status = "Low"
                anomaly_desc = f"{display_test_name}: {value} {unit} (Low - Normal: >{current_low} {range_unit}{range_note})"
                anomalies.append(anomaly_desc)
            else:
                # No specific range or within non-anomalous single limit
                pass # Status remains normal or undefined if no clear range is given

            table_data_list.append({
                "Test": display_test_name,
                "Value": f"{value} {unit or ''}".strip(),
                "Reference Range": f"{current_low}-{current_high} {range_unit}{range_note}".strip() if current_low is not None and current_high is not None else f"<{current_high} {range_unit}{range_note}".strip() if current_high is not None else f">{current_low} {range_unit}{range_note}".strip() if current_low is not None else "N/A",
                "Status": status
            })
            logging.info(f"Analyzed {display_test_name}: Value {value}, Status: {status}")
        else:
            # Test not found in NORMAL_RANGES
            table_data_list.append({
                "Test": display_test_name,
                "Value": f"{value} {unit or ''}".strip(),
                "Reference Range": "Not in knowledge base",
                "Status": "Unknown"
            })
            logging.warning(f"Test '{test_key}' not found in NORMAL_RANGES.")

    if not anomalies:
        logging.info("No anomalies detected in the lab report.")
    else:
        logging.info(f"Detected {len(anomalies)} anomalies in the lab report.")
    return table_data_list, anomalies

def get_gemini_explanation(anomalies, disease_context=None):
    """
    Uses Gemini AI to generate an explanation for anomalies in a lab report.
    Can also incorporate specific disease context if provided.
    """
    if report_explanation_model is None:
        logging.error("Gemini model for report explanation is not initialized.")
        return "Error: AI model for explanation could not be initialized."

    prompt_parts = [
        "You are an AI medical assistant. Provide a concise, general explanation for the following lab report anomalies. If no anomalies are listed, state that the report seems normal. Keep the explanation easy to understand for a non-medical person. Do not provide diagnosis or treatment advice. Focus on what the high/low value *might generally indicate* and recommend consulting a doctor. \n\n",
        "Anomalies: \n"
    ]
    if anomalies:
        prompt_parts.append("\n".join(anomalies))
    else:
        prompt_parts.append("No significant anomalies detected. All values appear within normal ranges.")

    if disease_context:
        prompt_parts.append(f"\n\nAdditional context provided by user: '{disease_context}'. Consider this context if relevant, but focus primarily on the lab anomalies.")

    prompt_parts.append("\n\nExplanation:")

    full_prompt = "".join(prompt_parts)
    logging.info(f"Sending prompt to Gemini for report explanation (first 100 chars): '{full_prompt[:100]}...'")

    try:
        response = report_explanation_model.generate_content(full_prompt)
        if response.text:
            logging.info("Gemini explanation generated successfully.")
            return response.text
        else:
            logging.warning("Gemini did not return text for report explanation.")
            return "AI could not generate a detailed explanation. Please try again."
    except genai.types.BlockedPromptException as e:
        logging.warning(f"Report explanation prompt blocked by AI safety filters. Details: {e}")
        return "I'm sorry, I cannot provide a response to that specific query due to safety guidelines."
    except Exception as e:
        logging.exception(f"An unexpected error occurred during Gemini explanation generation: {e}")
        return f"An error occurred while generating the explanation: {e}"


def report_parser_tab():
    """
    Streamlit UI for the lab report analyzer.
    """
    st.header("🔬 Lab Report Analyzer")
    st.markdown("Paste your lab report text below. The AI will identify common lab values, compare them to general normal ranges, and provide an explanation for any anomalies.")

    gender_input = st.radio("Select Gender (for gender-specific ranges):", ("Unknown", "Male", "Female"))
    
    report_text_input = st.text_area("Paste your lab report text here:", height=300, 
                                     placeholder="Example:\nWBC: 7500 cells/mcL\nHemoglobin: 14.5 g/dL\nGlucose: 95 mg/dL\nLDL: 125 mg/dL")
    disease_context_input = st.text_input("Optional: Add any relevant medical context or suspected condition (e.g., 'I have diabetes', 'Concerned about fatigue'):")

    if st.button("Analyze Report"):
        if not report_text_input:
            st.warning("Please paste your lab report text to analyze.")
            logging.info("Report analysis attempted with empty input.")
            return

        with st.spinner("Analyzing your report..."):
            parsed_data = parse_lab_results(report_text_input)

            if not parsed_data:
                st.info("No detectable lab test values found from your input. Please ensure you list tests and values clearly (e.g., 'Hemoglobin: 14, Glucose: 90'). Common formats: 'Test: Value Unit' or 'Test Value'.")
                logging.info("Report parsing resulted in no data.")
                return

            # Get both table data and AI explanation anomalies
            table_data_list, anomalies_for_ai = analyze_report_data(parsed_data, gender_input.lower())

            # Create a Pandas DataFrame for better table display in Streamlit
            df = pd.DataFrame(table_data_list)
            
            st.markdown("### Your Lab Results Overview:")
            st.dataframe(df) # Display the table

            # Only get Gemini explanation if there are actual anomalies or if user provided context
            gemini_explanation = ""
            if anomalies_for_ai or disease_context_input:
                gemini_explanation = get_gemini_explanation(anomalies_for_ai, disease_context_input)
            else:
                gemini_explanation = "All identified report parameters are within the normal range based on our knowledge base. No specific AI explanation needed for findings within normal ranges."


            response_parts = []
            response_parts.append("\n*AI's General Explanation:*")
            response_parts.append(gemini_explanation)
            response_parts.append("\n\n---\n*Disclaimer: This tool provides general information based on typical lab ranges and is not a substitute for professional medical advice, diagnosis, or treatment. Lab results should always be interpreted by a qualified doctor in the context of your full medical history.*")

            st.markdown("\n".join(response_parts))