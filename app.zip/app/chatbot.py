# app/chatbot.py

import google.generativeai as genai
import os
from dotenv import load_dotenv
import streamlit as st
import re
import logging # Ensure logging is imported

# Import knowledge bases from their respective modules
from app.report_parser import NORMAL_RANGES # Corrected import
from app.symptom_checker import MEDICAL_KNOWLEDGE_BASE # Corrected import

# Load API key from .env file
load_dotenv()

# --- Debugging: Print API Key ---\
_api_key = os.getenv("GEMINI_API_KEY")
if not _api_key:
    logging.critical("CRITICAL ERROR: GEMINI_API_KEY not found. Please ensure it's set in your .env file.")
else:
    logging.info(f"DEBUG: Retrieved API Key (first 5 chars): {_api_key[:5]}...")

genai.configure(api_key=_api_key)

MODEL_NAME = "gemini-2.0-flash"

# Global chat model instance (initialized once)
chat_model_instance = None
try:
    chat_model_instance = genai.GenerativeModel(MODEL_NAME)
    logging.info("DEBUG: Gemini model for chatbot initialized successfully.")
except Exception as e:
    logging.error(f"ERROR: Failed to initialize Gemini model for chatbot: {e}")
    st.error(f"Error initializing AI model. Please check your API key and internet connection: {e}")


# --- Helper function to get relevant knowledge from KBs ---
def _get_relevant_knowledge(query):
    """
    Retrieves relevant information from predefined knowledge bases based on the query.
    This is a simplified approach; in a real-world scenario, this might involve
    more sophisticated search or embedding-based retrieval.
    """
    relevant_info = []

    # Check against symptom checker knowledge base
    # Convert query to lowercase for matching
    lower_query = query.lower()

    # Simple keyword matching for symptom-related queries
    found_symptoms = [symptom for symptom_list in MEDICAL_KNOWLEDGE_BASE.values() for symptom in symptom_list if symptom in lower_query]
    if found_symptoms:
        # You might want to retrieve conditions related to these symptoms
        # For simplicity, we'll just indicate symptoms were found
        relevant_info.append(f"User mentioned symptoms: {', '.join(set(found_symptoms))}.")

    # Check against report parser knowledge base (e.g., if a lab test name is mentioned)
    found_lab_tests = [test for test in NORMAL_RANGES.keys() if test in lower_query]
    if found_lab_tests:
        relevant_info.append(f"User mentioned lab tests: {', '.join(set(found_lab_tests))}.")

    # If no specific KB info, you might consider general medical facts here
    # For now, it will just return what it found from the existing KBs.
    
    return relevant_info if relevant_info else []


def start_new_chat_session():
    """Starts a new chat session with the Gemini model."""
    if chat_model_instance:
        st.session_state.chat_session = chat_model_instance.start_chat(history=[])
        logging.info("New chat session started.")
    else:
        st.session_state.chat_session = None
        logging.error("Failed to start new chat session: chat_model_instance is None.")

# --- NEW: Function to classify if a query is medical or non-medical ---
def _is_medical_query(query):
    """
    Uses Gemini to classify if a query is medical or non-medical.
    Returns True if medical, False otherwise.
    """
    if not chat_model_instance:
        logging.error("AI model not initialized for medical query classification. Defaulting to True.")
        return True # Default to true to not block the user entirely if classification fails

    try:
        # A concise prompt to get a clear classification
        classification_prompt = (
            f"Classify the following user query as 'MEDICAL' or 'NON-MEDICAL'. "
            f"Respond with only one word: 'MEDICAL' or 'NON-MEDICAL'.\n\n"
            f"Query: \"{query}\""
        )
        response = chat_model_instance.generate_content(classification_prompt,
                                                        generation_config=genai.types.GenerationConfig(
                                                            temperature=0.0, # Make it deterministic
                                                            max_output_tokens=5 # Expecting only one word
                                                        ))
        classification = response.text.strip().upper()
        logging.info(f"Query '{query[:50]}...' classified as: {classification}")
        return classification == "MEDICAL"
    except Exception as e:
        logging.error(f"Error classifying query '{query[:50]}...': {e}. Defaulting to True.")
        # If classification fails, assume it's medical to avoid blocking valid queries
        return True

def doctor_chatbot_response(user_input):
    """
    Interacts with the Gemini AI to provide general health-related answers,
    maintaining conversation context and integrating knowledge base information.
    Only responds to medical queries.
    """
    # This check ensures that if start_new_chat_session failed, we gracefully handle it.
    if st.session_state.chat_session is None or chat_model_instance is None:
        return "❌ Error: AI model for general chat could not be initialized. Please check API key and model availability."

    # First, classify the query as medical or non-medical
    if not _is_medical_query(user_input):
        return ("I am DocBot, your AI medical assistant. My purpose is to provide "
                "information and assistance related to health and medical topics only. "
                "Please ask me a medical or health-related question.")

    try:
        # Retrieve relevant information from knowledge bases
        kb_info = _get_relevant_knowledge(user_input)
        
        # Construct the prompt. If KB info is found, augment the user's input.
        augmented_user_message = user_input
        if kb_info:
            kb_prefix = "\\n\\n".join(kb_info)
            augmented_user_message = f"{kb_prefix}\\n\\nUser's actual query: {user_input}"
        
        response = st.session_state.chat_session.send_message(augmented_user_message)

        if response.text:
            return response.text + "\\n\\n*Disclaimer: This is not medical advice. Please consult a certified doctor.*"
        else:
            return "DocBot couldn't generate a response for your query. Please try again."

    except Exception as e:
        # Catching specific API errors might be useful here (e.g., genai.types.BlockedPromptException)
        logging.exception(f"An error occurred during DocBot response generation: {e}")
        return f"An error occurred while generating a response: {e}. Please try again later."