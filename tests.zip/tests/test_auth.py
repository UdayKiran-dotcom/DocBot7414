import unittest
import sqlite3
import os
import sys
import time # Import time for a small delay workaround

# Add the 'app' directory to the Python path to allow imports from it
# This must be done BEFORE importing modules from 'app'
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'app')))

# Import auth module with an alias to clearly refer to its components
import app.auth as auth_module

# Store the original DATABASE_NAME from auth_module before overriding for tests
ORIGINAL_AUTH_DATABASE_NAME = auth_module.DATABASE_NAME

# Define a test database name to avoid conflicting with production db
TEST_DATABASE_NAME = "test_users.db"

class TestAuth(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # Override the database name in the auth module for testing
        auth_module.DATABASE_NAME = TEST_DATABASE_NAME
        
        # Initialize the test database using the auth module's init_db function.
        # This ensures auth's own connection handling is used for creation.
        auth_module.init_db()
        
        print(f"\nDEBUG: Initialized test database: {auth_module.DATABASE_NAME}")

    @classmethod
    def tearDownClass(cls):
        # Restore original DATABASE_NAME in the auth module
        auth_module.DATABASE_NAME = ORIGINAL_AUTH_DATABASE_NAME
        
        # Clean up the test database file
        if os.path.exists(TEST_DATABASE_NAME):
            # Attempt to close any potential lingering connections by connecting and closing
            try:
                conn_check = sqlite3.connect(TEST_DATABASE_NAME)
                conn_check.close()
            except Exception as e:
                print(f"WARNING: Could not connect/close DB before removal attempt in tearDownClass: {e}")

            # Introduce a small delay, often helps on Windows to release file handles
            time.sleep(0.1) 
            try:
                os.remove(TEST_DATABASE_NAME)
                print(f"DEBUG: Removed test database: {TEST_DATABASE_NAME}")
            except PermissionError as e:
                print(f"ERROR: PermissionError while removing test database '{TEST_DATABASE_NAME}': {e}")
                print("This might be due to a lingering file handle. Manual cleanup may be required after tests finish.")
            except Exception as e:
                print(f"ERROR: Failed to remove test database '{TEST_DATABASE_NAME}': {e}")

    def setUp(self):
        # Clear users table before each test to ensure test isolation
        conn = sqlite3.connect(TEST_DATABASE_NAME)
        c = conn.cursor()
        try:
            c.execute("DELETE FROM users")
            conn.commit()
        finally:
            conn.close()

    def test_add_user_success(self):
        print(f"Running test_add_user_success with DB: {TEST_DATABASE_NAME}")
        # Call add_user via auth_module to ensure it uses the test DB name
        self.assertTrue(auth_module.add_user("testuser1", "password123"), "Should successfully add a new user")
        
        # Verify user directly from the database using a new connection
        # This new connection should see the committed data from auth_module.add_user
        conn = sqlite3.connect(TEST_DATABASE_NAME)
        c = conn.cursor()
        try:
            c.execute("SELECT * FROM users WHERE username='testuser1'")
            self.assertIsNotNone(c.fetchone(), "User should be found in the database after addition")
        finally:
            conn.close()

    def test_add_user_duplicate(self):
        print(f"Running test_add_user_duplicate with DB: {TEST_DATABASE_NAME}")
        self.assertTrue(auth_module.add_user("testuser2", "password123"), "Should successfully add the first user")
        self.assertFalse(auth_module.add_user("testuser2", "anotherpassword"), "Should fail to add a duplicate user")

    def test_verify_user_correct_password(self):
        print(f"Running test_verify_user_correct_password with DB: {TEST_DATABASE_NAME}")
        auth_module.add_user("testuser3", "securepass")
        self.assertTrue(auth_module.verify_user("testuser3", "securepass"), "Should verify user with correct password")

    def test_verify_user_incorrect_password(self):
        print(f"Running test_verify_user_incorrect_password with DB: {TEST_DATABASE_NAME}")
        auth_module.add_user("testuser4", "correctpass")
        self.assertFalse(auth_module.verify_user("testuser4", "wrongpass"), "Should not verify user with incorrect password")

    def test_verify_user_non_existent(self):
        print(f"Running test_verify_user_non_existent with DB: {TEST_DATABASE_NAME}")
        self.assertFalse(auth_module.verify_user("nonexistent", "anypass"), "Should not verify non-existent user")

if __name__ == '__main__':
    unittest.main()