# tests/test_report_parser.py

import unittest
import sys
import os

# Add the 'app' directory to the Python path to allow imports from it
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'app')))

from report_parser import parse_lab_results, analyze_report_data, NORMAL_RANGES

class TestReportParser(unittest.TestCase):

    def test_parse_lab_results_basic(self):
        text = "WBC: 7500 cells/mcL, Hemoglobin: 14.5 g/dL, Glucose: 95 mg/dL"
        expected = {
            "wbc (white blood cell)": {"value": 7500.0, "unit": "cells/mcL"},
            "hemoglobin": {"value": 14.5, "unit": "g/dL"},
            "glucose": {"value": 95.0, "unit": "mg/dL"}
        }
        # We need to be careful with the keys because parse_lab_results normalizes them
        # The normalization from "WBC" to "wbc (white blood cell)" depends on the regex and NORMAL_RANGES keys.
        # Let's adjust expected based on how our parse_lab_results truly normalizes.
        # Assuming current parse_lab_results finds "wbc (white blood cell)" from "WBC"
        result = parse_lab_results(text)
        self.assertIn("wbc (white blood cell)", result)
        self.assertIn("hemoglobin", result)
        self.assertIn("glucose", result)
        self.assertAlmostEqual(result["wbc (white blood cell)"]["value"], 7500.0)
        self.assertEqual(result["wbc (white blood cell)"]["unit"], "cells/mcL")
        self.assertAlmostEqual(result["hemoglobin"]["value"], 14.5)
        self.assertEqual(result["hemoglobin"]["unit"], "g/dL")
        self.assertAlmostEqual(result["glucose"]["value"], 95.0)
        self.assertEqual(result["glucose"]["unit"], "mg/dL")


    def test_parse_lab_results_variations(self):
        text = "RBC 5.2 M/uL, Platelets: 250000 /uL"
        result = parse_lab_results(text)
        self.assertIn("rbc (red blood cell)", result)
        self.assertIn("platelets", result)
        self.assertAlmostEqual(result["rbc (red blood cell)"]["value"], 5.2)
        self.assertEqual(result["rbc (red blood cell)"]["unit"], "M/uL")
        self.assertAlmostEqual(result["platelets"]["value"], 250000.0)
        self.assertEqual(result["platelets"]["unit"], "/uL")


    def test_parse_lab_results_missing_units(self):
        text = "Cholesterol: 200, Triglycerides 150"
        result = parse_lab_results(text)
        self.assertIn("cholesterol (total)", result) # Should normalize to "cholesterol (total)"
        self.assertIn("triglycerides", result)
        self.assertAlmostEqual(result["cholesterol (total)"]["value"], 200.0)
        # If unit is not parsed, it should use the default from NORMAL_RANGES, or be None
        self.assertEqual(result["cholesterol (total)"]["unit"], NORMAL_RANGES["cholesterol (total)"]["unit"]) 
        self.assertAlmostEqual(result["triglycerides"]["value"], 150.0)
        self.assertEqual(result["triglycerides"]["unit"], NORMAL_RANGES["triglycerides"]["unit"])


    def test_parse_lab_results_no_matches(self):
        text = "Some random text that has no lab values"
        self.assertEqual(parse_lab_results(text), {})

    def test_analyze_report_data_normal_values(self):
        parsed_data = {
            "wbc (white blood cell)": {"value": 7000.0, "unit": "cells/mcL"},
            "hemoglobin": {"value": 14.0, "unit": "g/dL"} # Using generic hemoglobin for simplicity in test
        }
        table_data, anomalies = analyze_report_data(parsed_data, "male")
        self.assertEqual(len(anomalies), 0)
        
        # Check for WBC in table_data
        wbc_entry = next((item for item in table_data if item["Test"] == "Wbc"), None)
        self.assertIsNotNone(wbc_entry)
        self.assertEqual(wbc_entry["Value"], "7000.0 cells/mcL")
        self.assertEqual(wbc_entry["Status"], "Normal")

        # Check for Hemoglobin in table_data
        hgb_entry = next((item for item in table_data if item["Test"] == "Hemoglobin"), None)
        self.assertIsNotNone(hgb_entry)
        self.assertEqual(hgb_entry["Value"], "14.0 g/dL")
        self.assertEqual(hgb_entry["Status"], "Normal")


    def test_analyze_report_data_high_value(self):
        parsed_data = {
            "wbc (white blood cell)": {"value": 15000.0, "unit": "cells/mcL"}
        }
        table_data, anomalies = analyze_report_data(parsed_data, "female")
        self.assertEqual(len(anomalies), 1)
        
        wbc_entry = next((item for item in table_data if item["Test"] == "Wbc"), None)
        self.assertIsNotNone(wbc_entry)
        self.assertEqual(wbc_entry["Value"], "15000.0 cells/mcL")
        self.assertEqual(wbc_entry["Status"], "High")
        self.assertIn("Wbc: 15000.0 cells/mcL (High - Normal range: 4500-11000 cells/mcL)", anomalies[0])


    def test_analyze_report_data_low_value(self):
        parsed_data = {
            "hemoglobin": {"value": 10.0, "unit": "g/dL"}
        }
        table_data, anomalies = analyze_report_data(parsed_data, "female") # Use female for gender-specific test
        self.assertEqual(len(anomalies), 1)
        
        hgb_entry = next((item for item in table_data if item["Test"] == "Hemoglobin"), None)
        self.assertIsNotNone(hgb_entry)
        self.assertEqual(hgb_entry["Value"], "10.0 g/dL")
        self.assertEqual(hgb_entry["Status"], "Low")
        # Note: The actual anomaly string might vary slightly based on the exact range
        self.assertIn("Hemoglobin: 10.0 g/dL (Low - Normal range: 12.0-15.5 g/dL (Female))", anomalies[0])

    def test_analyze_report_data_gender_specific(self):
        parsed_data = {
            "hemoglobin": {"value": 16.0, "unit": "g/dL"}
        }
        # Male should be normal
        table_data_male, anomalies_male = analyze_report_data(parsed_data, "male")
        self.assertEqual(len(anomalies_male), 0)
        hgb_entry_male = next((item for item in table_data_male if item["Test"] == "Hemoglobin"), None)
        self.assertEqual(hgb_entry_male["Status"], "Normal")
        self.assertEqual(hgb_entry_male["Reference Range"], "13.5-17.5 g/dL (Male)")

        # Female should be high
        table_data_female, anomalies_female = analyze_report_data(parsed_data, "female")
        self.assertEqual(len(anomalies_female), 1)
        hgb_entry_female = next((item for item in table_data_female if item["Test"] == "Hemoglobin"), None)
        self.assertEqual(hgb_entry_female["Status"], "High")
        self.assertEqual(hgb_entry_female["Reference Range"], "12.0-15.5 g/dL (Female)")


if __name__ == '__main__':
    unittest.main()