# app/symptom_checker.py

import google.generativeai as genai
import os
from dotenv import load_dotenv
import streamlit as st
import logging # Add this line

# Configure logging (consider moving this to main.py or a config file for app-wide configuration)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Load API key from .env file
load_dotenv()

# Configure Gemini with API key
_api_key = os.getenv("GEMINI_API_KEY")
if not _api_key:
    logging.critical("CRITICAL ERROR: GEMINI_API_KEY not found in symptom_checker.py. Please set it in your .env file.")
    st.error("Configuration Error: API key not found for symptom checking.")
    genai.configure(api_key="dummy_key") # Dummy key to prevent immediate crash
else:
    genai.configure(api_key=_api_key)
    logging.info("Gemini configured for symptom_checker.")


# Use gemini-2.0-flash for faster responses, crucial for interactive applications
MODEL_NAME_FLASH = "gemini-2.0-flash"

# Initialize the generative model once globally for symptom extraction
symptom_extraction_model = None
try:
    symptom_extraction_model = genai.GenerativeModel(MODEL_NAME_FLASH)
    logging.info("Gemini model for symptom extraction initialized successfully.")
except Exception as e:
    logging.exception(f"Error initializing Gemini model for symptom extraction: {e}")
    st.error(f"Error initializing AI model for symptom extraction. Please check your API key and internet connection: {e}")


# --- Medical Knowledge Base (Expanded and Curated) ---
# This dictionary contains a significantly expanded set of common diseases
# and their associated symptoms. Each disease maps to a list of its common symptoms.
# Using lower case for symptoms for easier matching after Gemini extraction.
MEDICAL_KNOWLEDGE_BASE = {
    # Common Infections / Respiratory
    "common cold": ["runny nose", "sore throat", "cough", "sneezing", "mild headache", "tiredness", "nasal congestion"],
    "influenza (flu)": ["fever", "chills", "body aches", "fatigue", "sore throat", "cough", "headache", "vomiting", "diarrhea"],
    "strep throat": ["sore throat", "fever", "swollen lymph nodes", "difficulty swallowing", "white patches on tonsils", "headache"],
    "bronchitis": ["cough", "mucus production", "fatigue", "shortness of breath", "chest discomfort"],
    "pneumonia": ["cough", "fever", "chills", "shortness of breath", "chest pain", "fatigue"],
    "sinusitis": ["facial pain", "headache", "nasal congestion", "runny nose", "post-nasal drip", "sore throat"],

    # Digestive Issues
    "gastroenteritis (stomach flu)": ["nausea", "vomiting", "diarrhea", "abdominal cramps", "low-grade fever"],
    "irritable bowel syndrome (ibs)": ["abdominal pain", "cramping", "bloating", "gas", "diarrhea", "constipation"],
    "acid reflux (gerd)": ["heartburn", "regurgitation", "chest pain", "difficulty swallowing", "cough"],
    "appendicitis": ["sudden pain in lower right abdomen", "nausea", "vomiting", "loss of appetite", "fever"],

    # Skin Conditions
    "eczema": ["itchy skin", "red patches", "dry skin", "flaky skin", "rashes"],
    "acne": ["pimples", "blackheads", "whiteheads", "cysts", "skin redness"],
    "hives (urticaria)": ["itchy welts", "redness", "swelling of skin"],

    # Musculoskeletal / Pain
    "tension headache": ["dull, aching head pain", "tightness or pressure across forehead or back of head", "scalp tenderness"],
    "migraine": ["severe headache", "throbbing pain", "sensitivity to light", "sensitivity to sound", "nausea", "vomiting", "aura"],
    "arthritis": ["joint pain", "joint stiffness", "swelling", "reduced range of motion"],
    "sprain": ["pain in joint", "swelling", "bruising", "limited movement after injury"],

    # Mental Health / Neurological (simplified for a chatbot context)
    "anxiety": ["worry", "restlessness", "fatigue", "difficulty concentrating", "irritability", "muscle tension", "sleep disturbance"],
    "depression": ["persistent sadness", "loss of interest", "fatigue", "changes in appetite", "sleep problems", "feelings of worthlessness", "difficulty concentrating"],

    # Other Common Conditions
    "urinary tract infection (uti)": ["painful urination", "frequent urination", "urgency to urinate", "pelvic pain", "cloudy urine"],
    "allergies": ["sneezing", "itchy eyes", "runny nose", "nasal congestion", "skin rash", "hives"],
    "diabetes (uncontrolled)": ["frequent urination", "increased thirst", "increased hunger", "fatigue", "blurred vision", "slow-healing sores", "unexplained weight loss"],
    "hypothyroidism": ["fatigue", "weight gain", "cold sensitivity", "constipation", "dry skin", "hoarseness", "muscle weakness"],
    "hyperthyroidism": ["weight loss", "rapid heartbeat", "nervousness", "tremor", "sweating", "heat sensitivity", "fatigue"],
}

def extract_symptoms_from_text(symptoms_text):
    """
    Uses Gemini AI to extract a structured list of symptoms from free-form text.
    """
    if symptom_extraction_model is None:
        logging.error("Gemini model for symptom extraction is not initialized.")
        return []

    prompt = (
        f"Extract a comma-separated list of individual symptoms from the following text. "
        f"Only list distinct symptoms. Do not include severity or duration, just the symptom itself. "
        f"If no clear symptoms are present, respond with 'none'.\n\nText: {symptoms_text}"
    )
    logging.info(f"Sending prompt to Gemini for symptom extraction (first 100 chars): '{prompt[:100]}...'")

    try:
        response = symptom_extraction_model.generate_content(prompt)
        extracted_text = response.text.strip().lower()
        
        if "none" in extracted_text or not extracted_text:
            logging.info("Gemini extracted no symptoms or 'none'.")
            return []
        
        # Clean and split the extracted symptoms
        # Remove any leading/trailing commas, extra spaces
        symptoms_list = [s.strip() for s in extracted_text.split(',') if s.strip()]
        logging.info(f"Gemini extracted symptoms: {symptoms_list}")
        return symptoms_list
    except genai.types.BlockedPromptException as e:
        logging.warning(f"Symptom extraction prompt blocked by AI safety filters. Details: {e}")
        st.error("I'm sorry, I cannot process that symptom description due to safety guidelines. Please rephrase.")
        return []
    except Exception as e:
        logging.exception(f"An unexpected error occurred during symptom extraction: {e}")
        st.error(f"An error occurred during symptom extraction: {e}. Please try again.")
        return []

def suggest_conditions(extracted_symptoms):
    """
    Suggests possible medical conditions based on extracted symptoms by matching against MEDICAL_KNOWLEDGE_BASE.
    Returns a list of (condition, match_score) tuples, sorted by score.
    """
    if not extracted_symptoms:
        logging.info("No symptoms provided for condition suggestion.")
        return []

    symptom_matches = {}

    for condition, known_symptoms in MEDICAL_KNOWLEDGE_BASE.items():
        match_count = 0
        for symptom in extracted_symptoms:
            if symptom in known_symptoms:
                match_count += 1
        
        if match_count > 0:
            # Calculate a score based on number of matched symptoms vs. total known symptoms for condition
            # This is a simple ratio, you can refine this score calculation
            score = match_count / len(known_symptoms)
            symptom_matches[condition] = score
    
    # Sort conditions by match score in descending order
    suggested = sorted(symptom_matches.items(), key=lambda item: item[1], reverse=True)
    logging.info(f"Suggested conditions: {suggested}")
    return suggested

def symptom_checker_tab():
    """
    Streamlit UI for the symptom checker.
    """
    st.header("🤒 Symptom Checker")
    st.markdown("Enter your symptoms below, and the AI will suggest possible conditions based on its knowledge.")

    symptoms_input = st.text_area("Describe your symptoms (e.g., 'I have a fever, sore throat, and a cough.'):", height=150)

    if st.button("Check Symptoms"):
        if not symptoms_input:
            st.warning("Please describe your symptoms to proceed.")
            logging.info("Symptom check attempted with empty input.")
            return

        with st.spinner("Analyzing symptoms..."):
            extracted_symptoms = extract_symptoms_from_text(symptoms_input)

            if not extracted_symptoms:
                st.info("I couldn't identify any specific symptoms from your description. Please try to be more precise or describe common, distinct symptoms (e.g., 'fever', 'sore throat', 'cough').")
                logging.info("Symptom extraction resulted in no data.")
                return

            suggested_conditions = suggest_conditions(extracted_symptoms)

            response_parts = []
            response_parts.append(f"*Identified Symptoms:* {', '.join(extracted_symptoms).capitalize()}.")

            if suggested_conditions:
                response_parts.append("\n*Possible Conditions based on your symptoms (Please consult a doctor):*")
                for i, (condition, score) in enumerate(suggested_conditions):
                    response_parts.append(f"{i+1}. *{condition.title()}* (Match Score: {score:.0%})")
                response_parts.append("\n*The match score indicates how many of your identified symptoms align with typical symptoms for this condition in our knowledge base. Higher scores mean a stronger match.*")
            else:
                response_parts.append("\nBased on the symptoms provided, I couldn't find a strong direct match in my knowledge base. Your symptoms might be indicative of something not in my current database, or they may be mild and not indicative of a serious condition. *Please consult a certified medical doctor for a proper diagnosis.*")

            response_parts.append("\n\n---\n*Disclaimer: This symptom checker is for informational purposes only and is not a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of a qualified health provider for any questions regarding a medical condition.*")

            st.markdown("\n".join(response_parts))