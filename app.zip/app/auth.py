import sqlite3
import bcrypt
import os
import logging # Add this line

# Configure logging (consider moving this to main.py or a config file for app-wide configuration)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

DATABASE_NAME = "users.db" # This will create a file named users.db in your app directory

def init_db():
    """Initializes the SQLite database and creates the users table if it doesn't exist."""
    conn = None
    try:
        conn = sqlite3.connect(DATABASE_NAME)
        c = conn.cursor()
        c.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        ''')
        conn.commit()
        logging.info(f"Database '{DATABASE_NAME}' initialized successfully.")
    except sqlite3.Error as e:
        logging.error(f"Error initializing database '{DATABASE_NAME}': {e}")
    finally:
        if conn:
            conn.close()

def add_user(username, password):
    """
    Adds a new user to the database after hashing their password.
    Returns True on success, False if username already exists, or None on error.
    """
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    conn = None
    try:
        conn = sqlite3.connect(DATABASE_NAME)
        c = conn.cursor()
        c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
        conn.commit()
        logging.info(f"User '{username}' added successfully.")
        return True
    except sqlite3.IntegrityError:
        logging.warning(f"Attempted to add duplicate user: '{username}'.")
        return False # Username already exists
    except Exception as e:
        logging.exception(f"Failed to add user '{username}': {e}")
        return None
    finally:
        if conn:
            conn.close()

def verify_user(username, password):
    """
    Verifies a user's password against the hashed password in the database.
    Returns True on successful verification, False otherwise.
    """
    conn = None
    try:
        conn = sqlite3.connect(DATABASE_NAME)
        c = conn.cursor()
        c.execute("SELECT password FROM users WHERE username = ?", (username,))
        result = c.fetchone()
        logging.info(f"Verification attempt for user: '{username}'")
        if result:
            stored_hashed_password = result[0].encode('utf-8')
            if bcrypt.checkpw(password.encode('utf-8'), stored_hashed_password):
                logging.info(f"User '{username}' verified successfully.")
                return True
            else:
                logging.warning(f"Invalid password for user: '{username}'.")
                return False
        else:
            logging.warning(f"User '{username}' not found during verification.")
            return False
    except Exception as e:
        logging.exception(f"An error occurred during user verification for '{username}': {e}")
        return False
    finally:
        if conn:
            conn.close()

# Note: The original file had a print statement for DATABASE_NAME in init_db().
# It's replaced by logging.info for consistency.